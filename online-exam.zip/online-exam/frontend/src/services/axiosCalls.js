// import apis from "./Apis";
// import axios from 'axios';

// // export const Get = async (url, options) => {
// //   console.log('get api call')
// //   return (await axios.get(url, options));
// // }

// // export const Post =(p)=>{
// //   return axios({
// //       baseURL : apis.BASE,
// //       method:'post',
// //       ...p,
// //   })
// // }